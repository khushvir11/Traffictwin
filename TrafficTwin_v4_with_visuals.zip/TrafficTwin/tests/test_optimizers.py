"""Sanity tests for GA, PSO, and Hybrid GA-PSO optimizers on a simple
analytic benchmark function (Sphere function), independent of the traffic
simulation — validates the optimizers converge correctly before trusting
them on the expensive traffic-calibration objective."""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
from traffictwin.optimization import (
    run_ga, GAConfig, run_pso, PSOConfig, run_hybrid_ga_pso, HybridConfig,
)


def sphere(x: np.ndarray) -> float:
    """Global minimum at x=0, f(0)=0. Simple convex benchmark."""
    return float(np.sum(x ** 2))


BOUNDS_LO = np.array([-10.0] * 5)
BOUNDS_HI = np.array([10.0] * 5)


def test_ga_converges_on_sphere():
    # GA is deliberately slower to locally converge than PSO/Hybrid (that's
    # the whole motivation for hybridizing) — give it a fair budget and
    # check strong relative improvement rather than an absolute threshold
    # tuned for the faster methods.
    cfg = GAConfig(pop_size=20, generations=60, seed=0)
    res = run_ga(sphere, BOUNDS_LO, BOUNDS_HI, cfg)
    assert res.best_fitness < res.history_best[0] * 0.1
    assert res.history_best[-1] <= res.history_best[0]


def test_pso_converges_on_sphere():
    cfg = PSOConfig(swarm_size=20, iterations=30, seed=0)
    res = run_pso(sphere, BOUNDS_LO, BOUNDS_HI, cfg)
    assert res.best_fitness < 1.0
    assert res.history_best[-1] <= res.history_best[0]


def test_hybrid_converges_on_sphere():
    cfg = HybridConfig(pop_size=20, generations=30, seed=0)
    res = run_hybrid_ga_pso(sphere, BOUNDS_LO, BOUNDS_HI, cfg)
    assert res.best_fitness < 1.0
    assert res.history_best[-1] <= res.history_best[0]


def test_hybrid_fitness_history_is_monotonic_nonincreasing():
    """Elitism guarantees the best-known fitness never gets worse."""
    cfg = HybridConfig(pop_size=16, generations=20, seed=3)
    res = run_hybrid_ga_pso(sphere, BOUNDS_LO, BOUNDS_HI, cfg)
    diffs = np.diff(res.history_best)
    assert np.all(diffs <= 1e-9)


def test_optimizers_respect_bounds():
    cfg_ga = GAConfig(pop_size=15, generations=10, seed=1)
    res_ga = run_ga(sphere, BOUNDS_LO, BOUNDS_HI, cfg_ga)
    assert np.all(res_ga.best_x >= BOUNDS_LO) and np.all(res_ga.best_x <= BOUNDS_HI)

    cfg_pso = PSOConfig(swarm_size=15, iterations=10, seed=1)
    res_pso = run_pso(sphere, BOUNDS_LO, BOUNDS_HI, cfg_pso)
    assert np.all(res_pso.best_x >= BOUNDS_LO) and np.all(res_pso.best_x <= BOUNDS_HI)

    cfg_hybrid = HybridConfig(pop_size=15, generations=10, seed=1)
    res_hybrid = run_hybrid_ga_pso(sphere, BOUNDS_LO, BOUNDS_HI, cfg_hybrid)
    assert np.all(res_hybrid.best_x >= BOUNDS_LO) and np.all(res_hybrid.best_x <= BOUNDS_HI)


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_")]
    failed = 0
    for t in tests:
        try:
            t()
            print(f"PASS: {t.__name__}")
        except AssertionError as e:
            failed += 1
            print(f"FAIL: {t.__name__}: {e}")
    print(f"\n{len(tests) - failed}/{len(tests)} passed")
    sys.exit(1 if failed else 0)


def test_equal_evaluation_budget():
    """GA, PSO and the hybrid must spend (nearly) the same number of fitness calls."""
    import numpy as np
    from traffictwin.optimization import run_ga, GAConfig, run_pso, PSOConfig, run_hybrid_ga_pso, HybridConfig

    def count(run, cfg):
        n = [0]
        def f(x):
            n[0] += 1
            return float(np.sum(np.asarray(x) ** 2))
        run(f, np.full(5, -5.0), np.full(5, 5.0), cfg)
        return n[0]

    ga = count(run_ga, GAConfig(pop_size=20, generations=10))
    pso = count(run_pso, PSOConfig(swarm_size=20, iterations=10))
    hyb = count(run_hybrid_ga_pso, HybridConfig(pop_size=20, generations=10))
    assert abs(hyb - pso) <= 0.15 * pso, (ga, pso, hyb)
    print(f"budget ok: GA={ga} PSO={pso} Hybrid={hyb}")


if __name__ == "__main__":
    test_equal_evaluation_budget()
