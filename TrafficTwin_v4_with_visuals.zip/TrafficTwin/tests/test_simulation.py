"""Basic sanity tests for the IDM ring-road simulation."""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
from traffictwin.simulation.idm import (
    run_simulation, SimulationConfig, PARAM_NAMES, idm_acceleration,
)
from traffictwin.simulation.ground_truth import generate_observed_dataset, TRUE_PARAMS


def test_idm_acceleration_free_flow_is_positive_below_desired_speed():
    # Vehicle well below desired speed with a huge gap should accelerate.
    accel = idm_acceleration(
        v=np.array([10.0]), gap=np.array([1000.0]), dv=np.array([0.0]),
        v0=28.0, T=1.4, a=1.2, b=2.0, s0=2.5,
    )
    assert accel[0] > 0


def test_idm_acceleration_decelerates_when_too_close():
    accel = idm_acceleration(
        v=np.array([25.0]), gap=np.array([1.0]), dv=np.array([5.0]),
        v0=28.0, T=1.4, a=1.2, b=2.0, s0=2.5,
    )
    assert accel[0] < 0


def test_simulation_runs_and_shapes_match():
    cfg = SimulationConfig(n_vehicles=10, ring_length=500.0, dt=0.2, duration=20.0, warmup=5.0, seed=1)
    result = run_simulation(TRUE_PARAMS, cfg)
    n_steps_expected = int((cfg.duration - cfg.warmup) / cfg.dt)
    assert result.position.shape == (n_steps_expected, cfg.n_vehicles)
    assert result.velocity.shape == (n_steps_expected, cfg.n_vehicles)
    assert np.all(result.velocity >= 0)


def test_simulation_accepts_array_params_in_correct_order():
    cfg = SimulationConfig(n_vehicles=8, ring_length=400.0, dt=0.2, duration=15.0, warmup=5.0, seed=2)
    params_array = [TRUE_PARAMS[k] for k in PARAM_NAMES]
    result = run_simulation(params_array, cfg)
    assert result.mean_speed.shape[0] > 0


def test_higher_density_reduces_mean_speed():
    """Sanity check the fundamental diagram shape: more vehicles on a fixed
    ring should not increase mean speed (congestion effect)."""
    low_cfg = SimulationConfig(n_vehicles=8, ring_length=1200.0, dt=0.2, duration=100.0, warmup=40.0, seed=5)
    high_cfg = SimulationConfig(n_vehicles=50, ring_length=1200.0, dt=0.2, duration=100.0, warmup=40.0, seed=5)
    low_result = run_simulation(TRUE_PARAMS, low_cfg)
    high_result = run_simulation(TRUE_PARAMS, high_cfg)
    assert high_result.mean_speed.mean() < low_result.mean_speed.mean()


def test_generate_observed_dataset_shapes():
    obs = generate_observed_dataset(seed=1)
    assert obs.densities.shape == obs.mean_speeds.shape == obs.flows.shape
    assert np.all(obs.mean_speeds > 0)
    assert np.all(obs.flows >= 0)


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_")]
    failed = 0
    for t in tests:
        try:
            t()
            print(f"PASS: {t.__name__}")
        except AssertionError as e:
            failed += 1
            print(f"FAIL: {t.__name__}: {e}")
    print(f"\n{len(tests) - failed}/{len(tests)} passed")
    sys.exit(1 if failed else 0)
