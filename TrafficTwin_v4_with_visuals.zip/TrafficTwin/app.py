#!/usr/bin/env python3
"""
TrafficTwin web dashboard.

A thin Flask wrapper around run_calibration.py:
  - Lets you configure population/generations/seed/output dir from a form.
  - Launches the calibration run as a subprocess so the UI stays responsive.
  - Streams live log output to the browser via Server-Sent Events (SSE).
  - Once finished, serves the generated plots and calibration_results.json.

Run with:
    python app.py
Then open http://127.0.0.1:5000 in a browser.
"""

from __future__ import annotations

import json
import subprocess
import sys
import threading
import time
from pathlib import Path

from flask import Flask, Response, jsonify, request, send_from_directory, render_template

BASE_DIR = Path(__file__).resolve().parent

app = Flask(__name__, template_folder=str(BASE_DIR / "templates"), static_folder=str(BASE_DIR / "static"))

# ---------------------------------------------------------------------------
# In-memory run state (single-run-at-a-time; fine for a local dev dashboard)
# ---------------------------------------------------------------------------
_state_lock = threading.Lock()
_state = {
    "running": False,
    "log": [],           # list[str] of accumulated stdout lines
    "outdir": "results",  # last-used output directory (relative to BASE_DIR)
    "returncode": None,
    "process": None,      # subprocess.Popen handle
    "started_at": None,
}


def _reset_state(outdir: str):
    with _state_lock:
        _state["running"] = True
        _state["log"] = []
        _state["outdir"] = outdir
        _state["returncode"] = None
        _state["process"] = None
        _state["started_at"] = time.time()


def _append_log(line: str):
    with _state_lock:
        _state["log"].append(line)


def _run_subprocess(args: list[str]):
    """Runs run_calibration.py with the given CLI args, streaming stdout
    into the shared state's log list as it arrives."""
    cmd = [sys.executable, "-u", str(BASE_DIR / "run_calibration.py")] + args
    proc = subprocess.Popen(
        cmd,
        cwd=str(BASE_DIR),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
    )
    with _state_lock:
        _state["process"] = proc

    for line in proc.stdout:
        _append_log(line.rstrip("\n"))

    proc.wait()
    with _state_lock:
        _state["running"] = False
        _state["returncode"] = proc.returncode


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/run", methods=["POST"])
def api_run():
    with _state_lock:
        if _state["running"]:
            return jsonify({"error": "A run is already in progress."}), 409

    payload = request.get_json(force=True, silent=True) or {}
    outdir = (payload.get("outdir") or "results").strip() or "results"
    # keep output dirs inside the project folder — no path traversal
    outdir = outdir.replace("..", "").strip("/\\") or "results"

    args = ["--outdir", outdir]
    if payload.get("quick"):
        args.append("--quick")
    else:
        pop = payload.get("pop")
        gens = payload.get("gens")
        if pop:
            args += ["--pop", str(int(pop))]
        if gens:
            args += ["--gens", str(int(gens))]
    seed = payload.get("seed")
    if seed not in (None, "",):
        args += ["--seed", str(int(seed))]

    rep = payload.get("repeats")
    if rep not in (None, ""):
        args += ["--repeats", str(max(1, min(int(rep), 10)))]

    _reset_state(outdir)
    thread = threading.Thread(target=_run_subprocess, args=(args,), daemon=True)
    thread.start()

    return jsonify({"started": True, "outdir": outdir, "args": args})


@app.route("/api/stream")
def api_stream():
    """Server-Sent Events stream of log lines for the current/last run."""

    def generate():
        last_sent = 0
        while True:
            with _state_lock:
                lines = _state["log"][last_sent:]
                last_sent = len(_state["log"])
                running = _state["running"]
                returncode = _state["returncode"]

            for line in lines:
                yield f"data: {json.dumps(line)}\n\n"

            if not running and returncode is not None:
                yield f"event: done\ndata: {json.dumps({'returncode': returncode})}\n\n"
                break
            if not running and returncode is None and last_sent == 0:
                # no run started yet / nothing to stream
                yield f"event: idle\ndata: {{}}\n\n"
                break

            time.sleep(0.5)

    return Response(generate(), mimetype="text/event-stream")


@app.route("/api/status")
def api_status():
    with _state_lock:
        return jsonify({
            "running": _state["running"],
            "returncode": _state["returncode"],
            "outdir": _state["outdir"],
            "log_lines": len(_state["log"]),
        })


@app.route("/api/results")
def api_results():
    outdir = request.args.get("outdir", _state["outdir"] or "results")
    outdir = outdir.replace("..", "").strip("/\\") or "results"
    result_dir = BASE_DIR / outdir

    if not result_dir.exists():
        return jsonify({"exists": False})

    images = sorted(p.name for p in result_dir.glob("*.png"))
    summary = None
    summary_path = result_dir / "calibration_results.json"
    if summary_path.exists():
        try:
            summary = json.loads(summary_path.read_text())
        except Exception:
            summary = None

    return jsonify({
        "exists": True,
        "outdir": outdir,
        "images": images,
        "summary": summary,
    })


@app.route("/outputs/<path:outdir>/<path:filename>")
def serve_output_file(outdir, filename):
    outdir = outdir.replace("..", "").strip("/\\")
    result_dir = BASE_DIR / outdir
    return send_from_directory(str(result_dir), filename)


if __name__ == "__main__":
    print("TrafficTwin dashboard running at http://127.0.0.1:5000")
    app.run(host="127.0.0.1", port=5000, debug=False, threaded=True)
