#!/usr/bin/env python3
"""
TrafficTwin — end-to-end calibration experiment.

Runs:
  1. Generate synthetic "observed" traffic data from known ground-truth IDM
     parameters (simulating noisy loop-detector measurements).
  2. Calibrate the IDM model against that data using three optimizers:
       - Genetic Algorithm (GA)
       - Particle Swarm Optimization (PSO)
       - Hybrid GA-PSO  (this project's main contribution)
  3. Compare convergence speed, final fit quality, and parameter-recovery
     accuracy across the three methods.
  4. Save plots and a results table to ./results/.

Usage:
    python run_calibration.py [--quick]

    --quick   Use a smaller population / fewer generations for a fast
              smoke-test run (~1-2 minutes instead of ~15-20 minutes).
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import numpy as np

from traffictwin.simulation import (
    generate_observed_dataset, PARAM_NAMES, PARAM_BOUNDS, TRUE_PARAMS,
)
from traffictwin.calibration import CalibrationProblem
from traffictwin.optimization import (
    run_ga, GAConfig,
    run_pso, PSOConfig,
    run_hybrid_ga_pso, HybridConfig,
    run_de, DEConfig,
)
from traffictwin.analysis import fundamental_curve, sensitivity_profile, param_errors
from traffictwin.visualization.plots import (
    plot_convergence, plot_parameter_recovery, plot_fundamental_diagram, plot_trajectories,
)


def main():
    parser = argparse.ArgumentParser(description="TrafficTwin calibration experiment")
    parser.add_argument("--quick", action="store_true", help="fast smoke-test run")
    parser.add_argument("--pop", type=int, default=None, help="population/swarm size (overrides --quick default)")
    parser.add_argument("--gens", type=int, default=None, help="generations/iterations (overrides --quick default)")
    parser.add_argument("--outdir", type=str, default="results", help="output directory for plots/results")
    parser.add_argument("--seed", type=int, default=0, help="base random seed for optimizers")
    parser.add_argument("--objective", choices=["basic", "rich"], default="rich", help="rich adds spread/accel/braking/gap features")
    parser.add_argument("--repeats", type=int, default=1, help="extra independent seeds per method for the robustness benchmark")
    args = parser.parse_args()

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    print("=" * 70)
    print("TrafficTwin — Hybrid GA-PSO Traffic Simulation Calibration")
    print("=" * 70)

    # ---- 1. Generate synthetic observed data -----------------------------
    print("\n[1/4] Generating synthetic observed traffic data (ground truth + sensor noise)...")
    observed = generate_observed_dataset(seed=7)
    print(f"      Ground truth parameters : { {k: round(v, 3) for k, v in TRUE_PARAMS.items()} }")
    print(f"      Density sweep points    : {len(observed.densities)}  "
          f"(range {observed.densities.min():.1f}-{observed.densities.max():.1f} veh/km)")

    problem = CalibrationProblem(observed, fast_eval=True, objective=args.objective)
    bounds_lo = np.array([PARAM_BOUNDS[p][0] for p in PARAM_NAMES])
    bounds_hi = np.array([PARAM_BOUNDS[p][1] for p in PARAM_NAMES])

    # ---- 2. Configure optimizers (equal budget for fair comparison) ------
    if args.quick:
        pop, gens = 12, 8
    else:
        pop, gens = 24, 25
    if args.pop is not None:
        pop = args.pop
    if args.gens is not None:
        gens = args.gens

    ga_cfg = GAConfig(pop_size=pop, generations=gens, seed=args.seed)
    pso_cfg = PSOConfig(swarm_size=pop, iterations=gens, seed=args.seed)
    hybrid_cfg = HybridConfig(pop_size=pop, generations=gens, seed=args.seed)
    de_cfg = DEConfig(pop_size=pop, generations=gens, seed=args.seed)

    print(f"\n[2/4] Running optimizers  (pop/swarm={pop}, generations/iterations={gens})...")

    results = {}
    timings = {}

    for name, run_fn, cfg in [
        ("GA", run_ga, ga_cfg),
        ("PSO", run_pso, pso_cfg),
        ("Hybrid GA-PSO", run_hybrid_ga_pso, hybrid_cfg),
        ("DE", run_de, de_cfg),
    ]:
        print(f"      -> {name} ...", end=" ", flush=True)
        t0 = time.time()
        problem.n_evaluations = 0
        res = run_fn(problem.evaluate, bounds_lo, bounds_hi, cfg)
        res.n_evaluations = problem.n_evaluations  # count real simulator calls
        elapsed = time.time() - t0
        timings[name] = elapsed
        results[name] = res
        print(f"done in {elapsed:.1f}s | best fitness = {res.best_fitness:.4f} | evals = {res.n_evaluations}")

    # ---- 3. Report parameter recovery accuracy ----------------------------
    print("\n[3/4] Parameter recovery (recovered vs true):")
    print(f"      {'param':<6}{'true':>10}" + "".join(f"{name:>18}" for name in results))
    for j, pname in enumerate(PARAM_NAMES):
        row = f"      {pname:<6}{TRUE_PARAMS[pname]:>10.3f}"
        for name, res in results.items():
            row += f"{res.best_x[j]:>18.3f}"
        print(row)

    best_method = min(results, key=lambda m: results[m].best_fitness)
    print(f"\n      Best fit overall: {best_method}  (fitness={results[best_method].best_fitness:.4f})")

    # ---- 4. Plots & results export ----------------------------------------
    print("\n[4/4] Saving plots and results to", outdir.resolve())
    plot_convergence(results, str(outdir / "convergence_comparison.png"))
    plot_parameter_recovery(results, TRUE_PARAMS, PARAM_BOUNDS, str(outdir / "parameter_recovery.png"))

    for name, res in results.items():
        safe_name = name.lower().replace(" ", "_").replace("-", "_")
        calibrated_params = dict(zip(PARAM_NAMES, res.best_x))
        plot_fundamental_diagram(observed, calibrated_params, name, str(outdir / f"fundamental_diagram_{safe_name}.png"))

    best_params = dict(zip(PARAM_NAMES, results[best_method].best_x))
    plot_trajectories(best_params, n_vehicles=26, save_path=str(outdir / "trajectories_calibrated.png"),
                       title=f"Time-Space Trajectories — {best_method} calibrated model")
    plot_trajectories(TRUE_PARAMS, n_vehicles=26, save_path=str(outdir / "trajectories_ground_truth.png"),
                       title="Time-Space Trajectories — Ground Truth model")

    print("\n      Diagnostics: fitted curves + sensitivity ...")
    curves = {n: fundamental_curve(dict(zip(PARAM_NAMES, r.best_x))) for n, r in results.items()}
    curves["Ground truth"] = fundamental_curve(TRUE_PARAMS)
    sens = sensitivity_profile(problem, TRUE_PARAMS)

    bench = {n: {"final": [float(results[n].best_fitness)]} for n in results}
    for rep in range(1, args.repeats):
        for name, run_fn, cfg_cls, key in [("GA", run_ga, GAConfig, "pop_size"), ("PSO", run_pso, PSOConfig, "swarm_size"), ("Hybrid GA-PSO", run_hybrid_ga_pso, HybridConfig, "pop_size"), ("DE", run_de, DEConfig, "pop_size")]:
            kw = {key: pop, ("iterations" if name == "PSO" else "generations"): gens, "seed": args.seed + rep}
            r = run_fn(problem.evaluate, bounds_lo, bounds_hi, cfg_cls(**kw))
            bench[name]["final"].append(float(r.best_fitness))
        print(f"      repeat {rep + 1}/{args.repeats} done")
    for n, b in bench.items():
        b["mean"], b["std"], b["best"] = float(np.mean(b["final"])), float(np.std(b["final"])), float(np.min(b["final"]))

    summary = {
        "true_params": TRUE_PARAMS,
        "results": {
            name: {
                "best_params": dict(zip(PARAM_NAMES, res.best_x.tolist())),
                "best_fitness": res.best_fitness,
                "n_evaluations": res.n_evaluations,
                "runtime_seconds": timings[name],
                "history_best": [float(v) for v in res.history_best],
                "history_mean": [float(v) for v in res.history_mean],
            }
            for name, res in results.items()
        },
        "best_method": best_method,
        "objective": args.objective,
        "budget": {"pop": pop, "gens": gens, "seed": args.seed},
        "bounds": {k: list(v) for k, v in PARAM_BOUNDS.items()},
        "observed": {"density": observed.densities.tolist(), "speed": observed.mean_speeds.tolist(), "flow": observed.flows.tolist()},
        "curves": curves,
        "sensitivity": sens,
        "benchmark": bench,
        "param_error": {n: param_errors(dict(zip(PARAM_NAMES, r.best_x)), TRUE_PARAMS) for n, r in results.items()},
    }
    with open(outdir / "calibration_results.json", "w") as f:
        json.dump(summary, f, indent=2)

    print("\nSaved:")
    for p in sorted(outdir.glob("*")):
        print("   ", p)
    print("\nDone.")


if __name__ == "__main__":
    main()
