"""Builds the presentation figures in ./explain from the real simulator and saved results.
Run:  python make_explainer_figures.py
"""
import json, sys
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle, Wedge, FancyBboxPatch as FB

ROOT = Path(__file__).parent; OUT = ROOT / "explain"; OUT.mkdir(exist_ok=True)
sys.path.insert(0, str(ROOT))
from traffictwin.simulation.ground_truth import RING_LENGTH, TRUE_PARAMS
from traffictwin.simulation.idm import SimulationConfig, run_simulation

BG, CARD, INK, MUTE, LINE = "#f3f0e8", "#fbfaf6", "#1c1d21", "#76736a", "#ded9cc"
GA, PSO, HY, DE, AMB = "#c4533a", "#2c4f85", "#16805f", "#8a6a1f", "#e0a030"
plt.rcParams.update({"font.family": "DejaVu Sans", "figure.facecolor": BG, "axes.facecolor": BG,
                     "savefig.facecolor": BG, "text.color": INK, "axes.edgecolor": LINE})
SERIF = {"family": "DejaVu Serif"}


def canvas(w=14, h=7.6, title="", sub="", equal=False):
    fig = plt.figure(figsize=(w, h)); ax = fig.add_axes([0, 0, 1, .86])
    ax.set_xlim(0, 100); ax.set_ylim(0, 100 * (h * .86) / w if equal else 100); ax.axis("off")
    fig.text(.04, .94, title, fontsize=21, fontweight="bold", **SERIF)
    if sub: fig.text(.04, .895, sub, fontsize=11.5, color=MUTE)
    return fig, ax


def box(ax, x, y, w, h, head, body="", fc=CARD, ec=LINE, hc=INK, fs=12.5, lw=1.4):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.4,rounding_size=1.6", fc=fc, ec=ec, lw=lw))
    ax.text(x + w / 2, y + h * (.64 if body else .5), head, ha="center", va="center", fontsize=fs, fontweight="bold", color=hc)
    if body: ax.text(x + w / 2, y + h * .30, body, ha="center", va="center", fontsize=fs - 2.6, color=MUTE, linespacing=1.4)


def arrow(ax, a, b, rad=0, color=INK, lw=1.8, label="", lx=0, ly=0, ls="-"):
    ax.add_patch(FancyArrowPatch(a, b, arrowstyle="-|>", mutation_scale=16, lw=lw, color=color, connectionstyle=f"arc3,rad={rad}", linestyle=ls))
    if label: ax.text((a[0] + b[0]) / 2 + lx, (a[1] + b[1]) / 2 + ly, label, ha="center", fontsize=10, color=color, style="italic")


# ---------------------------------------------------------------- 1. pipeline
def fig_pipeline():
    fig, ax = canvas(title="The big picture: rediscover how people drive", sub="Two stages. First we fabricate a 'real world' with a secret driver style. Then algorithms try to find that secret from the data alone.")
    ax.text(3, 93, "STAGE 1  ·  create the data (done once)", fontsize=11, color=MUTE, fontweight="bold")
    box(ax, 3, 66, 26, 22, "Secret true driver", "v0 = 28 m/s   T = 1.4 s\na = 1.2   b = 2.0   s0 = 2.5 m", fc="#f4e3dc", ec=GA, hc=GA)
    box(ax, 38, 66, 24, 22, "Ring-road simulator", "cars follow each other\naround a 1.2 km loop")
    box(ax, 71, 66, 26, 22, "Sensor data + noise", "speed, flow, speed spread,\nacceleration, braking, gaps", fc="#fbf0d4", ec=AMB, hc="#7a5410")
    arrow(ax, (29.8, 77), (37.2, 77)); arrow(ax, (62.8, 77), (70.2, 77))
    ax.plot([3, 97], [55, 55], color=LINE, lw=1.2, ls=(0, (4, 4)))
    ax.text(3, 49, "STAGE 2  ·  rediscover it (the optimisation)", fontsize=11, color=MUTE, fontweight="bold")
    box(ax, 3, 22, 26, 22, "Optimiser guesses", "GA · PSO · Hybrid · DE\npropose 5 numbers", fc="#dcebe6", ec=HY, hc=HY)
    box(ax, 38, 22, 24, 22, "Same simulator", "drive the ring with\nthe guessed numbers")
    box(ax, 71, 22, 26, 22, "Loss = mismatch", "guessed world vs sensor data\nlower = better guess", fc="#dde6f3", ec=PSO, hc=PSO)
    arrow(ax, (29.8, 33), (37.2, 33)); arrow(ax, (62.8, 33), (70.2, 33))
    arrow(ax, (84, 65.4), (84, 45), color="#7a5410", ls="--", label="compare against", lx=9, ly=4)
    arrow(ax, (84, 21.2), (16, 21.2), rad=-.14, color=HY, lw=2.2, label="feedback: the score tells the optimiser what to try next", ly=-5.6)
    ax.text(50, 4.2, "Because we made the secret ourselves, we can finally check: did the algorithm find the right five numbers?", ha="center", fontsize=12, style="italic", color=INK)
    fig.savefig(OUT / "1_pipeline.png", dpi=180); plt.close(fig)


# ---------------------------------------------------------------- 2. the model
def fig_idm():
    fig, ax = canvas(title="What are the five numbers?", sub="Each car follows the car in front of it using the Intelligent Driver Model (IDM). These five numbers are the 'personality' we try to recover.", equal=True)
    cx, cy, R = 24, 23, 16.5
    ax.add_patch(Circle((cx, cy), R, fc="none", ec=LINE, lw=22, zorder=1)); ax.add_patch(Circle((cx, cy), R, fc="none", ec="#cfc9ba", lw=1, ls=(0, (6, 6)), zorder=2))
    n = 14; pos = lambda i: (cx + R * np.cos(np.pi / 2 - i * 2 * np.pi / n), cy + R * np.sin(np.pi / 2 - i * 2 * np.pi / n))
    for i in range(n):
        x, y = pos(i); col = HY if i == 0 else PSO if i == 1 else AMB
        ax.add_patch(FB((x - 1.3, y - 1.3), 2.6, 2.6, boxstyle="round,pad=0.1,rounding_size=0.7", fc=col, ec="white", lw=1.2, zorder=3))
    (lx, ly), (fx, fy) = pos(0), pos(1)
    ax.text(lx - 1, ly + 3.6, "leader", color=HY, fontsize=11, fontweight="bold", ha="center")
    ax.text(fx + 5.5, fy + 3.0, "follower", color=PSO, fontsize=11, fontweight="bold", ha="center")
    arrow(ax, (fx - 1.4, fy + 2.0), (lx + 2.0, ly + 1.6), rad=.35, color=MUTE, lw=1.4)
    ax.text(cx, cy + 3, "1.2 km ring", ha="center", fontsize=14, fontweight="bold", **SERIF)
    ax.text(cx, cy - 1.2, "cars never overtake,\nthey only react to the\ncar directly ahead", ha="center", va="top", fontsize=10.5, color=MUTE, linespacing=1.45)
    ax.text(cx, 1.6, "Each step the follower asks: how fast can I go\nwithout getting too close to the leader?", ha="center", fontsize=11, style="italic")
    rows = [("v0", "28 m/s", "Free speed", "How fast they drive on an empty road", GA),
            ("T", "1.4 s", "Time gap", "How many seconds behind the car ahead they like to stay", PSO),
            ("a", "1.2 m/s²", "Acceleration", "How firmly they speed up when the road opens", HY),
            ("b", "2.0 m/s²", "Comfortable braking", "How hard they brake when the car ahead slows", DE),
            ("s0", "2.5 m", "Jam gap", "The bumper gap they keep when fully stopped", "#6b4c9a")]
    for k, (sym, val, name, desc, col) in enumerate(rows):
        y = 39.5 - k * 8.2
        ax.add_patch(FancyBboxPatch((52, y - 3.1), 45, 6.2, boxstyle="round,pad=0.3,rounding_size=1.2", fc=CARD, ec=LINE, lw=1.2))
        ax.add_patch(FancyBboxPatch((53.2, y - 2.3), 9.5, 4.6, boxstyle="round,pad=0.2,rounding_size=1.0", fc=col, ec="none"))
        ax.text(58, y, sym, color="white", ha="center", va="center", fontsize=17, fontweight="bold", **SERIF)
        ax.text(64.5, y + 1.15, name, fontsize=13, fontweight="bold", va="center"); ax.text(95.5, y + 1.15, val, fontsize=12.5, ha="right", va="center", family="monospace", color=col, fontweight="bold")
        ax.text(64.5, y - 1.45, desc, fontsize=10.2, color=MUTE, va="center")
    fig.savefig(OUT / "2_driver_parameters.png", dpi=180); plt.close(fig)


# ---------------------------------------------------------------- 3. hybrid
def fig_hybrid():
    fig, ax = canvas(title="How the Hybrid GA-PSO works", sub="Every generation the population is split three ways. Strong guesses are kept, the middle moves like a swarm, the rest evolve like genes.")
    box(ax, 3, 38, 17, 24, "Population", "16 candidate drivers\n(5 numbers each)", fc="#eceae2", fs=13)
    box(ax, 27, 38, 15, 24, "Rank by loss", "best at the top", fs=13)
    arrow(ax, (20.8, 50), (26.2, 50)); arrow(ax, (42.8, 55), (50.2, 81), rad=-.15, color=DE); arrow(ax, (42.8, 50), (50.2, 50), rad=0, color=HY); arrow(ax, (42.8, 45), (50.2, 25), rad=.15, color=GA)
    box(ax, 51, 70, 28, 22, "Elite  (top few)", "copied untouched,\nnever lose a great guess", fc="#f1ead3", ec=DE, hc=DE, fs=13)
    box(ax, 51, 42, 28, 22, "PSO group", "each moves toward its own best\nand the swarm's best (momentum)", fc="#dcebe6", ec=HY, hc=HY, fs=13)
    box(ax, 51, 14, 28, 22, "GA group", "pick parents, mix their numbers\n(crossover), small random tweak", fc="#f4e3dc", ec=GA, hc=GA, fs=13)
    for y in (81, 53, 25): arrow(ax, (79.8, y), (86.4, 50 + (y - 50) * .55), color=MUTE)
    box(ax, 87, 38, 11, 24, "New\npopulation", "", fc="#eceae2", fs=12.5)
    ax.plot([92.5, 92.5, 11.5], [37, 8, 8], color=INK, lw=1.6, solid_capstyle="round")
    arrow(ax, (11.5, 8), (11.5, 37), color=INK, lw=1.6)
    ax.text(52, 9.8, "repeat for every generation", ha="center", fontsize=10.5, style="italic")
    ax.text(50, 1.2, "Why mix them?  PSO converges fast but can get stuck.  GA explores widely but wanders.  Together: fast and less likely to get trapped.", ha="center", fontsize=11.2, style="italic")
    fig.savefig(OUT / "3_hybrid_algorithm.png", dpi=180); plt.close(fig)


# ---------------------------------------------------------------- 4. space-time
def fig_spacetime():
    fig, axs = plt.subplots(1, 2, figsize=(14, 6.6), gridspec_kw={"wspace": .12})
    fig.subplots_adjust(top=.76, bottom=.14, left=.07, right=.9)
    fig.text(.04, .94, "What the simulator actually produces", fontsize=21, fontweight="bold", **SERIF)
    fig.text(.04, .885, "Every dot is a car on the ring (vertical = where, horizontal = when). Colour is speed. Same driver, different traffic density.", fontsize=11.5, color=MUTE)
    sc = None
    for ax, n, ttl in zip(axs, (10, 60), ("Light traffic: 8 cars/km, everyone cruises", "Heavy traffic: 50 cars/km, slow and tightly packed")):
        r = run_simulation(TRUE_PARAMS, SimulationConfig(n_vehicles=n, ring_length=RING_LENGTH, duration=240, warmup=0, seed=3))
        t = np.arange(r.position.shape[0]) * .2
        T = np.repeat(t[:, None], n, 1)
        sc = ax.scatter(T[:500].ravel(), (r.position[:500] % RING_LENGTH).ravel(), c=r.velocity[:500].ravel(), s=1.6, cmap="RdYlGn", vmin=0, vmax=28, rasterized=True)
        ax.set_title(ttl, fontsize=12.5, fontweight="bold", loc="left", pad=8); ax.set_xlabel("time (s)", color=MUTE); ax.set_facecolor(CARD)
        for s_ in ax.spines.values(): s_.set_color(LINE)
        ax.tick_params(colors=MUTE, labelsize=9.5)
    axs[0].set_ylabel("position on ring (m)", color=MUTE); axs[1].set_yticklabels([])
    cb = fig.colorbar(sc, ax=axs, fraction=.022, pad=.02); cb.set_label("speed (m/s)", color=MUTE); cb.outline.set_edgecolor(LINE); cb.ax.tick_params(colors=MUTE, labelsize=9)
    fig.text(.04, .04, "Sensors only see averages of this picture (mean speed, flow, spread...). The optimiser must work backwards from them to the five driver numbers.", fontsize=11, style="italic")
    fig.savefig(OUT / "4_traffic_simulation.png", dpi=180); plt.close(fig)


# ---------------------------------------------------------------- 5. why rich
def fig_identifiability():
    old, new = json.load(open(ROOT / "results_basic/calibration_results.json")), json.load(open(ROOT / "results/calibration_results.json"))
    names = [("a", "Acceleration  a"), ("b", "Braking  b"), ("s0", "Jam gap  s0")]
    fig, axs = plt.subplots(1, 3, figsize=(14, 5.9), gridspec_kw={"wspace": .22}); fig.subplots_adjust(top=.7, bottom=.2, left=.06, right=.97)
    fig.text(.04, .93, "The upgrade that made the problem solvable", fontsize=21, fontweight="bold", **SERIF)
    fig.text(.04, .83, "If the loss is flat when a parameter changes, no algorithm can find it. Speed and flow alone were blind to  a  and  b.\nAdding spread, acceleration, braking and gap signals gives every parameter a clear 'valley' at its true value.", fontsize=11.5, color=MUTE, linespacing=1.5)
    for ax, (k, lab) in zip(axs, names):
        for res, col, name, lw in ((old, "#a29d8f", "speed + flow only", 2.4), (new, HY, "rich objective", 2.8)):
            g, l = np.array(res["sensitivity"][k]["grid"]), np.array(res["sensitivity"][k]["loss"]); l = (l - l.min()) / (l.max() - l.min() + 1e-12) if res is new else (l - new_min(old, k)) / (new_rng(new, k) + 1e-12)
            ax.plot(g, l, color=col, lw=lw, label=name)
        ax.axvline(TRUE_PARAMS[k], color=INK, ls=(0, (3, 4)), lw=1.3); ax.text(TRUE_PARAMS[k], 1.04, "true", ha="center", fontsize=9.5, color=INK)
        ax.set_title(lab, fontsize=13, fontweight="bold", loc="left", pad=16); ax.set_ylim(-.04, 1.12); ax.set_xlabel("value tried", color=MUTE); ax.set_facecolor(CARD)
        for s_ in ax.spines.values(): s_.set_color(LINE)
        ax.tick_params(colors=MUTE, labelsize=9)
    axs[0].set_ylabel("loss (same scale)", color=MUTE); axs[0].legend(frameon=False, loc="lower right", fontsize=10)
    fig.text(.04, .05, "Reading it:  grey = flat line = 'the data cannot tell'.   green = sharp dip at the dotted line = 'the data points straight at the answer'.", fontsize=11, style="italic")
    fig.savefig(OUT / "5_why_rich_objective.png", dpi=180); plt.close(fig)


def new_min(res, k): return min(res["sensitivity"][k]["loss"])
def new_rng(res, k): return max(res["sensitivity"][k]["loss"]) - min(res["sensitivity"][k]["loss"])


if __name__ == "__main__":
    for f in (fig_pipeline, fig_idm, fig_hybrid, fig_spacetime, fig_identifiability):
        f(); print("ok", f.__name__)
