# TrafficTwin — Hybrid GA-PSO Traffic Simulation Calibration

A digital-twin calibration toolkit that recovers driver-behavior parameters
of a microscopic traffic simulation from noisy macroscopic traffic
measurements, using a **Hybrid Genetic Algorithm + Particle Swarm
Optimization (GA-PSO)** metaheuristic — benchmarked against standalone GA
and standalone PSO.

## What this does

1. **Simulates traffic** with the Intelligent Driver Model (IDM), a
   well-established car-following model, on a single-lane circular ring
   road (the standard testbed for calibration research because it has no
   boundary effects and reliably produces stop-and-go waves).
2. **Manufactures a calibration problem**: simulate the IDM with a known
   "true" parameter set across a sweep of vehicle densities, add sensor
   noise, and treat the result as data from real inductive-loop detectors.
3. **Calibrates** the simulation's 5 driver-behavior parameters
   (`v0, T, a, b, s0`) against that noisy data by minimizing RMSE between
   simulated and observed speed/flow, using three optimizers:
   - Genetic Algorithm (GA) — baseline
   - Particle Swarm Optimization (PSO) — baseline
   - **Hybrid GA-PSO** — this project's core contribution
4. **Compares** convergence speed, final fit quality, and parameter
   recovery accuracy across all three, with plots.

## Why hybridize GA and PSO?

- **GA** excels at *global exploration* (crossover recombines distant
  regions of the search space, mutation escapes local optima) but
  converges slowly once near an optimum.
- **PSO** excels at *local exploitation* (particles are pulled directly
  toward known-good solutions, converging fast) but a swarm can
  prematurely collapse onto a local optimum and lose diversity.

The hybrid combines both **within every generation**: elites survive
unchanged, a fraction of the population is updated via PSO velocity/
position rules (fast local search around promising regions), and the
remaining fraction is regenerated via GA selection + crossover + mutation
(maintains diversity, prevents premature convergence). Inertia weight and
mutation strength both decay over generations — explore broadly early,
fine-tune late. See `traffictwin/optimization/hybrid_ga_pso.py` for the
full design rationale in the module docstring.

## Presentation figures

`python make_explainer_figures.py` regenerates five explainer PNGs in `explain/` from the real simulator and saved results: the big picture, the five driver numbers, how the hybrid works, what the simulator produces, and why the richer objective was needed.

## What changed in v3

- **Rich objective (`--objective rich`, now the default).** Speed and flow alone
  leave `a` and `b` unidentifiable (loss is flat in them). The rich loss adds
  four texture features (speed spread, RMS acceleration, hard-braking level,
  minimum gap; see `simulation/features.py`), log-compressed so near-zero
  equilibrium features can't swamp the loss. All five parameters now show a
  clear minimum at their true value in the sensitivity sweep.
- **Differential Evolution baseline** (`optimization/de.py`) as a fourth method.
- **Honest reading of one small run** (176 evals each, 2 seeds): PSO and the
  hybrid are tied on loss and DE has the lowest parameter error, with `a` and `b`
  recovered to about 2%. Larger budgets are needed before ranking methods.
  `results_basic/` holds the v2 speed+flow run for comparison.

## What changed in v2

- **Fair comparison.** The original hybrid re-scored its whole population every
  generation and so spent ~1.9x the simulator calls of GA/PSO (578 vs 306).
  Scores are now reused, evaluations are counted from the objective itself, and
  `tests/test_optimizers.py` guards the budget.
- **Identifiability analysis** (`traffictwin/analysis`). A one-at-a-time loss
  sweep shows which parameters speed/flow data can actually constrain.
  Weakly identifiable ones (typically `a`, `b`, `s0`) recover poorly for every
  optimiser, which is a property of the data, not of the search.
- **Robustness benchmark.** `--repeats N` re-runs each method on N seeds and
  reports mean, std and best loss, so one lucky seed can't decide the ranking.
- **New dashboard.** Convergence, fitted fundamental diagrams, parameter
  recovery, benchmark and sensitivity charts, all drawn client-side in SVG
  (no CDN, works offline) from `results/calibration_results.json`.

## Web dashboard

A local Flask dashboard wraps `run_calibration.py` so you can configure and
launch runs, watch live progress, and browse results in a browser instead of
the terminal.

```bash
pip install -r requirements.txt   # now includes flask
python app.py
```

Then open **http://127.0.0.1:5000**. From there you can:

- Toggle **Quick mode** for a fast ~1-2 min smoke test, or set a custom
  population / generations / seed / output folder.
- Click **Run calibration** — it launches `run_calibration.py` as a
  subprocess and streams its stdout live into the page.
- Once finished, the page automatically loads the generated plots and the
  GA / PSO / Hybrid GA-PSO parameter-recovery table from
  `calibration_results.json`.

The dashboard is a thin wrapper (`app.py`, `templates/index.html`,
`static/`) — it doesn't change any calibration logic, it just runs the same
CLI script and displays the same output files. You can still run
`python run_calibration.py` directly from the terminal at any time; the
dashboard and CLI read/write the same `results/` folder.

Only one run can be in progress at a time (a local dev dashboard, not a
job queue) — the **Run calibration** button is disabled while a run is
active.

## Project structure

```
TrafficTwin/
├── app.py                     # Flask dashboard backend
├── templates/index.html       # dashboard page
├── static/style.css, app.js   # dashboard styling + client logic
├── traffictwin/
│   ├── simulation/
│   │   ├── idm.py            # IDM car-following model, ring-road simulator
│   │   └── ground_truth.py   # synthetic observed-data generator
│   ├── calibration/
│   │   └── objective.py      # RMSE fitness function (sim vs observed)
│   ├── optimization/
│   │   ├── ga.py              # standalone Genetic Algorithm
│   │   ├── pso.py             # standalone Particle Swarm Optimization
│   │   └── hybrid_ga_pso.py   # Hybrid GA-PSO (core contribution)
│   └── visualization/
│       └── plots.py          # convergence, fundamental diagram, trajectories
├── run_calibration.py        # end-to-end experiment runner (CLI)
├── configs/default.yaml      # reference config / default values
├── tests/                    # unit tests (optimizers on analytic benchmark
│                              #  + simulation sanity checks)
├── results/                  # generated plots + calibration_results.json
└── requirements.txt
```

## Installation

```bash
pip install -r requirements.txt
```

Pure NumPy/Matplotlib — no external simulator (SUMO/VISSIM) required. The
traffic model is self-contained, which keeps the whole pipeline runnable
anywhere without extra installs; swapping in a SUMO-driven objective later
only requires replacing `traffictwin/calibration/objective.py`.

## Usage

Run the full experiment (generates data, runs all 3 optimizers, saves
plots + JSON results to `results/`):

```bash
python run_calibration.py
```

Options:

```bash
python run_calibration.py --quick              # fast smoke test (~1 min)
python run_calibration.py --pop 24 --gens 25    # custom population/generation budget
python run_calibration.py --outdir my_results   # custom output directory
python run_calibration.py --seed 1              # different optimizer RNG seed
python run_calibration.py --repeats 5           # robustness benchmark over 5 seeds
```

Run tests:

```bash
python tests/test_simulation.py
python tests/test_optimizers.py
```

## Outputs

Each run produces in the output directory:

| File | Description |
|---|---|
| `convergence_comparison.png` | Best & mean fitness per generation, GA vs PSO vs Hybrid |
| `parameter_recovery.png` | Recovered parameter values vs ground truth, per method |
| `fundamental_diagram_<method>.png` | Speed-density & flow-density fit vs noisy observed data |
| `trajectories_calibrated.png` / `trajectories_ground_truth.png` | Time-space diagrams showing stop-and-go wave structure |
| `calibration_results.json` | Full numeric results: best params, fitness, runtime, convergence history |

## Method summary (for a report / paper)

- **Simulation model**: IDM (Treiber, Hennecke & Helbing, 2000), single-lane
  ring road, `N` vehicles, evaluated at 8 density points (8–62 vehicles on a
  1200 m ring).
- **Calibration targets**: mean speed and flow at each density point, with
  Gaussian sensor noise (σ = 0.6 m/s on speed, 5% on flow).
- **Objective**: combined normalized RMSE across speed and flow.
- **Search space**: `v0 ∈ [15,35] m/s`, `T ∈ [0.5,3] s`, `a ∈ [0.3,3] m/s²`,
  `b ∈ [0.5,5] m/s²`, `s0 ∈ [1,5] m`.
- **Optimizers compared** under equal evaluation budget: real-coded GA
  (tournament selection, SBX crossover, Gaussian mutation, elitism),
  inertia-weight PSO (Shi & Eberhart, 1998), and the Hybrid GA-PSO
  described above.
- **Evaluation**: convergence curves, final RMSE, and per-parameter
  recovery error against the known ground truth — something only possible
  because the "observed" data is synthetic in this experiment (real-world
  calibration can only check fit quality, not true parameter recovery,
  since the true parameters are unknown).

## Extending this project

- **Swap in a real simulator**: replace `run_simulation()` in
  `traffictwin/simulation/idm.py` with a SUMO/VISSIM TraCI call — the rest
  of the pipeline (objective, optimizers, plots) is simulator-agnostic.
- **Use real detector data**: replace `generate_observed_dataset()` with a
  loader for actual loop-detector or NGSIM trajectory data.
- **More parameters**: extend `PARAM_NAMES`/`PARAM_BOUNDS` in `idm.py` if
  calibrating a richer car-following or lane-changing model.
- **Multi-objective**: the objective currently combines speed+flow RMSE
  into one scalar; a Pareto-based hybrid (NSGA-II-style) could separate them.
