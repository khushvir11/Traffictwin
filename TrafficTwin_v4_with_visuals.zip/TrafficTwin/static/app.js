const $=s=>document.querySelector(s), NS="http://www.w3.org/2000/svg";
const COL={"GA":"#c4533a","PSO":"#2c4f85","Hybrid GA-PSO":"#16805f","DE":"#8a6a1f","Ground truth":"#1c1d21"};
const P=["v0","T","a","b","s0"], UNIT={v0:"m/s",T:"s",a:"m/s²",b:"m/s²",s0:"m"};
let DATA=null, fdKey="speed";
const f=(v,d=3)=>Number(v).toFixed(d);

function nice(lo,hi,n=5){const st=(hi-lo)/n,m=10**Math.floor(Math.log10(st||1)),r=st/m,s=(r<1.5?1:r<3?2:r<7?5:10)*m,a=Math.floor(lo/s+1e-9)*s,t=[];for(let i=0;i<40;i++){const v=+(a+i*s).toFixed(10);t.push(v);if(v>=hi-1e-9)break}return t}
function chart(el,{series=[],dots=[],vlines=[],xl="",yl="",ar=.36,fh,m=[14,18,40,50],yMin}){
  const W=Math.max(el.clientWidth||600,200),H=fh||Math.round(W*ar);
  const[mt,mr,mb,ml]=m,xs=[...series.flatMap(s=>s.x),...dots.flatMap(d=>d.x)],ys=[...series.flatMap(s=>s.y),...dots.flatMap(d=>d.y)];
  const x0=Math.min(...xs),x1=Math.max(...xs),yt=nice(yMin??Math.min(...ys),Math.max(...ys)),y0=yt[0],y1=yt.at(-1),xt=nice(x0,x1);
  const X=v=>ml+(v-x0)/(x1-x0||1)*(W-ml-mr),Y=v=>H-mb-(v-y0)/(y1-y0||1)*(H-mt-mb);
  let g=`<svg viewBox="0 0 ${W} ${H}" role="img">`;
  yt.forEach(v=>g+=`<line x1="${ml}" x2="${W-mr}" y1="${Y(v)}" y2="${Y(v)}" stroke="#e6e1d4"/><text x="${ml-8}" y="${Y(v)+3}" text-anchor="end">${+v.toPrecision(3)}</text>`);
  xt.filter(v=>v>=x0&&v<=x1).forEach(v=>g+=`<text x="${X(v)}" y="${H-mb+16}" text-anchor="middle">${+v.toPrecision(3)}</text>`);
  g+=`<text x="${(ml+W-mr)/2}" y="${H-4}" text-anchor="middle">${xl}</text><text transform="translate(11 ${(mt+H-mb)/2}) rotate(-90)" text-anchor="middle">${yl}</text>`;
  vlines.forEach(v=>g+=`<line x1="${X(v)}" x2="${X(v)}" y1="${mt}" y2="${H-mb}" stroke="#1c1d21" stroke-dasharray="3 4"/>`);
  series.forEach(s=>{g+=`<path d="${s.x.map((v,i)=>(i?"L":"M")+X(v).toFixed(1)+" "+Y(s.y[i]).toFixed(1)).join("")}" fill="none" stroke="${s.c}" stroke-width="${s.w||2.2}" ${s.d?'stroke-dasharray="5 4"':""} stroke-linejoin="round" stroke-linecap="round"/>`});
  dots.forEach(d=>d.x.forEach((v,i)=>g+=`<circle cx="${X(v)}" cy="${Y(d.y[i])}" r="3.6" fill="${d.c}" fill-opacity=".55" stroke="${d.c}"/>`));
  el.innerHTML=g+"</svg>";
}

function legend(){$("#leg").innerHTML=Object.keys(COL).filter(k=>k!=="Ground truth").map(k=>`<span><i style="background:${COL[k]}"></i>${k}</span>`).join("")}
function render(d){
  DATA=d;const R=d.results,names=Object.keys(R),best=d.best_method,b=d.budget||{};
  const win=names.reduce((a,n)=>d.benchmark&&d.benchmark[n].mean<d.benchmark[a].mean?n:a,names[0]);
  const ranked=[...names].sort((a,c)=>R[a].best_fitness-R[c].best_fitness);
  const nb=d.benchmark?Object.values(d.benchmark)[0].final.length:1,srt=names.map(n=>d.benchmark[n]).sort((a,c)=>a.mean-c.mean),gap=srt[1].mean-srt[0].mean,tie=nb>1&&gap<Math.max(srt[0].std,srt[1].std);
  const second=names.filter(n=>n!==win).sort((a,c)=>d.benchmark[a].mean-d.benchmark[c].mean)[0];
  $("#lede").textContent=`Objective: ${d.objective==='rich'?'speed, flow, speed spread, acceleration, braking and gaps':'speed and flow only'}. Every method got the same simulator budget (about ${R[names[0]].n_evaluations} evaluations, population ${b.pop}, ${b.gens} generations). On this seed ${best} found the lowest loss. `+(nb>1?(tie?`Over ${nb} seeds, ${win} and ${second} are statistically tied (gap ${f(gap,4)}, smaller than the seed-to-seed spread), so don't read a winner into one run.`:`Over ${nb} seeds, ${win} leads on mean loss.`):"Add repeats to test whether that ranking holds.");
  $("#kpis").innerHTML=ranked.map((n,i)=>`<div class="kpi ${i?"":"win"}"><small>${n}${i?"":" · lowest loss"}</small><b>${f(R[n].best_fitness,4)}</b><span>${R[n].n_evaluations} evals · ${f(R[n].runtime_seconds,0)} s</span></div>`).join("");
  chart($("#c-conv"),{series:names.map(n=>({c:COL[n],x:R[n].history_best.map((_,i)=>i),y:R[n].history_best})),xl:"generation",yl:"loss",ar:.3});legend();
  fd();
  // parameter error: grouped horizontal bars
  const E=d.param_error,W=520,rowH=80,H=P.length*rowH+8;let g=`<svg viewBox="0 0 ${W} ${H}">`,mx=Math.max(.05,...names.flatMap(n=>P.map(p=>E[n][p])));
  P.forEach((p,i)=>{const y=i*rowH+4;g+=`<text x="0" y="${y+12}" style="fill:#1c1d21;font-weight:600">${p}<tspan dx="6" style="fill:#76736a;font-weight:400">${f(d.true_params[p],1)} ${UNIT[p]}</tspan></text>`;
    names.forEach((n,j)=>{const w=E[n][p]/mx*(W-60);g+=`<rect x="0" y="${y+20+j*11}" width="${Math.max(w,2)}" height="8" rx="2" fill="${COL[n]}"/><text x="${w+6}" y="${y+28+j*11}">${(E[n][p]*100).toFixed(1)}%</text>`})});
  $("#c-err").innerHTML=g+"</svg>";
  // robustness table
  const B=d.benchmark;$("#bn").textContent=`${B[names[0]].final.length} independent seeds`;
  $("#bench").innerHTML=`<tr><th>Method</th><th class=n>Mean loss</th><th class=n>± Std</th><th class=n>Best</th></tr>`+names.map(n=>`<tr class="${n==win?"best":""}"><td><span style="color:${COL[n]}">●</span> ${n}</td><td class=n>${f(B[n].mean,4)}</td><td class=n>${f(B[n].std,4)}</td><td class=n>${f(B[n].best,4)}</td></tr>`).join("");
  // sensitivity
  const S=d.sensitivity,top=Math.max(...P.map(p=>S[p].sensitivity));
  $("#sens").innerHTML=P.map(p=>`<div><h4>${p}<span class="tag ${S[p].sensitivity/top>.25?"ok":""}">${S[p].sensitivity/top>.25?"identifiable":"weak signal"}</span></h4><small>Δloss ${f(S[p].sensitivity,3)} · true ${f(d.true_params[p],1)} ${UNIT[p]}</small><div id="s-${p}"></div></div>`).join("");
  P.forEach(p=>chart($("#s-"+p),{series:[{c:"#1c1d21",x:S[p].grid,y:S[p].loss,w:2}],vlines:[d.true_params[p]],fh:130,m:[8,8,22,38],yMin:0}));
  const weak=P.filter(p=>S[p].sensitivity/top<=.25);
  $("#sens-note").textContent=weak.length?`Speed and flow barely react to ${weak.join(", ")}, so no optimiser can pin them down from these detectors alone. That explains the larger recovery error above; it is a data limit, not a search failure.`:"All five parameters leave a clear fingerprint in the loss surface.";
}
function fd(){if(!DATA)return;const d=DATA,k=fdKey,ser=Object.entries(d.curves).map(([n,c])=>({c:COL[n]||"#888",x:c.density,y:c[k],d:n==="Ground truth",w:n==="Ground truth"?1.8:2.2}));
  chart($("#c-fd"),{series:ser,dots:[{c:"#e0a030",x:d.observed.density,y:d.observed[k]}],xl:"density (veh/km)",yl:k==="speed"?"mean speed (m/s)":"flow (veh/h)",yMin:0})}
document.querySelectorAll("#fd-tabs button").forEach(b=>b.onclick=()=>{document.querySelectorAll("#fd-tabs button").forEach(x=>x.classList.remove("on"));b.classList.add("on");fdKey=b.dataset.k;fd()});

const load=()=>fetch("/api/results").then(r=>r.json()).then(r=>{if(r.exists&&r.summary&&r.summary.curves)render(r.summary)});
$("#quick").onchange=e=>$("#custom").classList.toggle("off",e.target.checked);
$("#run-form").onsubmit=async e=>{e.preventDefault();const btn=$("#run-btn"),st=$("#run-status"),log=$("#log");
  const body={quick:$("#quick").checked,pop:+$("#pop").value,gens:+$("#gens").value,seed:+$("#seed").value,repeats:+$("#repeats").value};
  const r=await fetch("/api/run",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
  if(!r.ok){st.textContent=(await r.json()).error;return}
  btn.disabled=true;log.textContent="";st.className="status live";st.textContent="Calibrating…";
  const es=new EventSource("/api/stream");es.onmessage=m=>{log.textContent+=JSON.parse(m.data)+"\n";log.scrollTop=log.scrollHeight};
  es.addEventListener("done",ev=>{es.close();btn.disabled=false;const ok=JSON.parse(ev.data).returncode===0;st.className="status";st.textContent=ok?"Finished":"Run failed";if(ok)load()});};
let rt;addEventListener("resize",()=>{clearTimeout(rt);rt=setTimeout(()=>DATA&&render(DATA),150)});
load();
