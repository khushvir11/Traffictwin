"""
Hybrid GA-PSO Optimizer — core algorithm of TrafficTwin.

Design rationale
-----------------
GA is strong at *global exploration* — crossover recombines distant regions
of the search space and mutation escapes local optima, but convergence near
an optimum is slow and somewhat random.

PSO is strong at *local exploitation* — particles are pulled directly toward
the best-known solutions and converge fast, but a swarm can prematurely
collapse onto a local optimum and lose diversity.

This hybrid combines both operators **within every generation** rather than
running them in separate phases:

  1. The population is evaluated and sorted by fitness.
  2. The top `elite_frac` fraction survives unchanged (elitism).
  3. The next `pso_frac` fraction is regenerated via PSO velocity/position
     updates — pulled toward each individual's personal best and the
     population's global best. This drives fast local exploitation around
     promising regions.
  4. The remaining fraction is regenerated via GA operators — tournament
     selection + SBX crossover + Gaussian mutation. This maintains genetic
     diversity and global exploration, preventing the premature convergence
     PSO alone is prone to.
  5. An adaptive inertia weight and mutation strength both decay over
     generations, shifting the balance from exploration early on to
     exploitation later — mirroring how a human calibration engineer would
     work: cast a wide net first, then fine-tune.

Each individual carries its own PSO velocity and personal-best memory even
though only a subset is updated via PSO each generation, so an individual
that "graduates" into the PSO fraction in a later generation already has a
usable velocity/personal-best history.
"""

from __future__ import annotations

import numpy as np
from dataclasses import dataclass
from typing import Callable

from .ga import OptimizationResult, _tournament_select, _sbx_crossover


@dataclass
class HybridConfig:
    pop_size: int = 30
    generations: int = 40
    elite_frac: float = 0.1
    pso_frac: float = 0.5          # fraction of non-elite population updated via PSO
    # PSO-side coefficients
    inertia_start: float = 0.9
    inertia_end: float = 0.4
    cognitive_coeff: float = 1.6
    social_coeff: float = 1.6
    velocity_clamp_frac: float = 0.2
    # GA-side coefficients
    tournament_size: int = 3
    crossover_prob: float = 0.9
    sbx_eta: float = 15.0
    mutation_prob: float = 0.25
    mutation_sigma_start: float = 0.25
    mutation_sigma_end: float = 0.02
    seed: int = 0


def run_hybrid_ga_pso(
    fitness_fn: Callable[[np.ndarray], float],
    bounds_lo: np.ndarray,
    bounds_hi: np.ndarray,
    cfg: HybridConfig = HybridConfig(),
    callback: Callable[[int, np.ndarray, np.ndarray], None] | None = None,
) -> OptimizationResult:
    rng = np.random.default_rng(cfg.seed)
    dim = len(bounds_lo)
    range_ = bounds_hi - bounds_lo
    v_max = cfg.velocity_clamp_frac * range_

    n_elite = max(1, int(cfg.pop_size * cfg.elite_frac))
    n_remaining = cfg.pop_size - n_elite
    n_pso = max(1, int(round(n_remaining * cfg.pso_frac)))
    n_ga = n_remaining - n_pso

    # Population state
    pos = rng.uniform(bounds_lo, bounds_hi, size=(cfg.pop_size, dim))
    vel = rng.uniform(-v_max, v_max, size=(cfg.pop_size, dim))
    fitness = np.array([fitness_fn(p) for p in pos])

    pbest_pos = pos.copy()
    pbest_fit = fitness.copy()
    gbest_idx = np.argmin(pbest_fit)
    gbest_pos = pbest_pos[gbest_idx].copy()
    gbest_fit = pbest_fit[gbest_idx]

    history_best, history_mean = [gbest_fit], [fitness.mean()]

    for gen in range(cfg.generations):
        progress = gen / max(1, cfg.generations - 1)
        w = cfg.inertia_start + (cfg.inertia_end - cfg.inertia_start) * progress
        sigma = cfg.mutation_sigma_start + (cfg.mutation_sigma_end - cfg.mutation_sigma_start) * progress

        order = np.argsort(fitness)
        pos, vel, fitness = pos[order], vel[order], fitness[order]
        pbest_pos, pbest_fit = pbest_pos[order], pbest_fit[order]

        if fitness[0] < gbest_fit:
            gbest_fit = fitness[0]
            gbest_pos = pos[0].copy()

        history_best.append(gbest_fit)
        history_mean.append(fitness.mean())
        if callback:
            callback(gen, gbest_pos, fitness)

        # --- 1. Elitism: top individuals pass through untouched ---
        new_pos = [pos[i].copy() for i in range(n_elite)]
        new_vel = [vel[i].copy() for i in range(n_elite)]
        new_pbest_pos = [pbest_pos[i].copy() for i in range(n_elite)]
        new_pbest_fit = [pbest_fit[i] for i in range(n_elite)]
        new_fit = [fitness[i] for i in range(n_elite)]  # elites already scored

        # --- 2. PSO fraction: velocity/position update pulled toward pbest & gbest ---
        pso_idx = np.arange(n_elite, n_elite + n_pso)
        for i in pso_idx:
            r1, r2 = rng.random(dim), rng.random(dim)
            v_new = (
                w * vel[i]
                + cfg.cognitive_coeff * r1 * (pbest_pos[i] - pos[i])
                + cfg.social_coeff * r2 * (gbest_pos - pos[i])
            )
            v_new = np.clip(v_new, -v_max, v_max)
            p_new = np.clip(pos[i] + v_new, bounds_lo, bounds_hi)

            new_pos.append(p_new)
            new_vel.append(v_new)
            f_new = fitness_fn(p_new)
            new_fit.append(f_new)
            if f_new < pbest_fit[i]:
                new_pbest_pos.append(p_new.copy())
                new_pbest_fit.append(f_new)
            else:
                new_pbest_pos.append(pbest_pos[i].copy())
                new_pbest_fit.append(pbest_fit[i])

        # --- 3. GA fraction: tournament selection + SBX crossover + mutation ---
        ga_children = []
        while len(ga_children) < n_ga:
            p1 = _tournament_select(pos, fitness, cfg.tournament_size, rng)
            p2 = _tournament_select(pos, fitness, cfg.tournament_size, rng)
            if rng.random() < cfg.crossover_prob:
                c1, c2 = _sbx_crossover(p1, p2, bounds_lo, bounds_hi, cfg.sbx_eta, rng)
            else:
                c1, c2 = p1.copy(), p2.copy()
            for child in (c1, c2):
                if rng.random() < cfg.mutation_prob:
                    child = child + rng.normal(0, sigma * range_, size=dim)
                    child = np.clip(child, bounds_lo, bounds_hi)
                ga_children.append(child)
                if len(ga_children) >= n_ga:
                    break

        for child in ga_children:
            new_pos.append(child)
            new_vel.append(rng.uniform(-v_max, v_max, size=dim))  # fresh velocity for new genetic material
            f_child = fitness_fn(child)
            new_fit.append(f_child)
            new_pbest_pos.append(child.copy())
            new_pbest_fit.append(f_child)

        pos = np.array(new_pos[: cfg.pop_size])
        vel = np.array(new_vel[: cfg.pop_size])
        pbest_pos = np.array(new_pbest_pos[: cfg.pop_size])
        pbest_fit = np.array(new_pbest_fit[: cfg.pop_size])
        fitness = np.array(new_fit[: cfg.pop_size])  # reuse scores: no redundant re-evaluation

        gen_best_idx = np.argmin(pbest_fit)
        if pbest_fit[gen_best_idx] < gbest_fit:
            gbest_fit = pbest_fit[gen_best_idx]
            gbest_pos = pbest_pos[gen_best_idx].copy()

    order = np.argsort(fitness)
    final_best_fit = fitness[order][0]
    if final_best_fit < gbest_fit:
        gbest_fit = final_best_fit
        gbest_pos = pos[order][0].copy()
    history_best.append(gbest_fit)
    history_mean.append(fitness.mean())

    # Total evaluations: initial pop + per-generation (only the n_pso + n_ga new candidates)
    n_eval_per_gen = n_pso + n_ga
    n_evaluations = cfg.pop_size + cfg.generations * n_eval_per_gen

    return OptimizationResult(
        best_x=gbest_pos,
        best_fitness=gbest_fit,
        history_best=history_best,
        history_mean=history_mean,
        n_evaluations=n_evaluations,
        method="Hybrid GA-PSO",
    )
