"""
Standalone real-coded Genetic Algorithm — used as a calibration baseline.

Operators:
  - Tournament selection
  - Simulated Binary Crossover (SBX)
  - Gaussian mutation with per-generation decaying strength
  - Elitism (best individuals always survive)
"""

from __future__ import annotations

import numpy as np
from dataclasses import dataclass, field
from typing import Callable


@dataclass
class GAConfig:
    pop_size: int = 30
    generations: int = 40
    elite_frac: float = 0.1
    tournament_size: int = 3
    crossover_prob: float = 0.9
    sbx_eta: float = 15.0
    mutation_prob: float = 0.2
    mutation_sigma_start: float = 0.25   # fraction of parameter range
    mutation_sigma_end: float = 0.02
    seed: int = 0


@dataclass
class OptimizationResult:
    best_x: np.ndarray
    best_fitness: float
    history_best: list = field(default_factory=list)     # best fitness per generation
    history_mean: list = field(default_factory=list)     # mean fitness per generation
    n_evaluations: int = 0
    method: str = ""


def _tournament_select(pop, fitness, k, rng):
    idx = rng.integers(0, len(pop), size=k)
    best_idx = idx[np.argmin(fitness[idx])]
    return pop[best_idx].copy()


def _sbx_crossover(p1, p2, bounds_lo, bounds_hi, eta, rng):
    u = rng.random(len(p1))
    beta = np.where(
        u <= 0.5,
        (2 * u) ** (1.0 / (eta + 1)),
        (1.0 / (2 * (1 - u))) ** (1.0 / (eta + 1)),
    )
    c1 = 0.5 * ((1 + beta) * p1 + (1 - beta) * p2)
    c2 = 0.5 * ((1 - beta) * p1 + (1 + beta) * p2)
    return np.clip(c1, bounds_lo, bounds_hi), np.clip(c2, bounds_lo, bounds_hi)


def run_ga(
    fitness_fn: Callable[[np.ndarray], float],
    bounds_lo: np.ndarray,
    bounds_hi: np.ndarray,
    cfg: GAConfig = GAConfig(),
    callback: Callable[[int, np.ndarray, np.ndarray], None] | None = None,
) -> OptimizationResult:
    rng = np.random.default_rng(cfg.seed)
    dim = len(bounds_lo)
    n_elite = max(1, int(cfg.pop_size * cfg.elite_frac))

    pop = rng.uniform(bounds_lo, bounds_hi, size=(cfg.pop_size, dim))
    fitness = np.array([fitness_fn(ind) for ind in pop])

    history_best, history_mean = [], []

    for gen in range(cfg.generations):
        sigma = cfg.mutation_sigma_start + (cfg.mutation_sigma_end - cfg.mutation_sigma_start) * (
            gen / max(1, cfg.generations - 1)
        )

        order = np.argsort(fitness)
        pop, fitness = pop[order], fitness[order]
        history_best.append(fitness[0])
        history_mean.append(fitness.mean())
        if callback:
            callback(gen, pop[0], fitness)

        new_pop = [pop[i].copy() for i in range(n_elite)]  # elitism

        while len(new_pop) < cfg.pop_size:
            p1 = _tournament_select(pop, fitness, cfg.tournament_size, rng)
            p2 = _tournament_select(pop, fitness, cfg.tournament_size, rng)

            if rng.random() < cfg.crossover_prob:
                c1, c2 = _sbx_crossover(p1, p2, bounds_lo, bounds_hi, cfg.sbx_eta, rng)
            else:
                c1, c2 = p1.copy(), p2.copy()

            for child in (c1, c2):
                if rng.random() < cfg.mutation_prob:
                    child += rng.normal(0, sigma * (bounds_hi - bounds_lo), size=dim)
                    np.clip(child, bounds_lo, bounds_hi, out=child)
                new_pop.append(child)
                if len(new_pop) >= cfg.pop_size:
                    break

        pop = np.array(new_pop[: cfg.pop_size])
        fitness = np.array([fitness_fn(ind) for ind in pop])

    order = np.argsort(fitness)
    pop, fitness = pop[order], fitness[order]
    history_best.append(fitness[0])
    history_mean.append(fitness.mean())

    return OptimizationResult(
        best_x=pop[0],
        best_fitness=fitness[0],
        history_best=history_best,
        history_mean=history_mean,
        n_evaluations=cfg.pop_size * (cfg.generations + 1),
        method="GA",
    )
