"""Differential Evolution (rand/1/bin with jitter) - a strong, tuning-light baseline."""
from __future__ import annotations
import numpy as np
from dataclasses import dataclass
from .ga import OptimizationResult


@dataclass
class DEConfig:
    pop_size: int = 30
    generations: int = 40
    F: float = 0.6
    CR: float = 0.8
    seed: int = 0


def run_de(fitness_fn, bounds_lo, bounds_hi, cfg: DEConfig = DEConfig(), callback=None) -> OptimizationResult:
    rng = np.random.default_rng(cfg.seed)
    dim, n = len(bounds_lo), cfg.pop_size
    pop = rng.uniform(bounds_lo, bounds_hi, (n, dim))
    fit = np.array([fitness_fn(p) for p in pop])
    hb, hm = [fit.min()], [fit.mean()]
    for _ in range(cfg.generations):
        for i in range(n):
            a, b, c = pop[rng.choice([j for j in range(n) if j != i], 3, replace=False)]
            F = cfg.F * rng.uniform(0.7, 1.3)                       # dither
            mutant = np.clip(a + F * (b - c), bounds_lo, bounds_hi)
            cross = rng.random(dim) < cfg.CR
            cross[rng.integers(dim)] = True
            trial = np.where(cross, mutant, pop[i])
            ft = fitness_fn(trial)
            if ft <= fit[i]:
                pop[i], fit[i] = trial, ft
        hb.append(fit.min()); hm.append(fit.mean())
    k = int(np.argmin(fit))
    return OptimizationResult(best_x=pop[k].copy(), best_fitness=float(fit[k]), history_best=hb,
                              history_mean=hm, n_evaluations=n * (cfg.generations + 1), method="DE")
