"""
Standalone Particle Swarm Optimization — used as a calibration baseline.

Classic inertia-weight PSO (Shi & Eberhart, 1998) with linearly decaying
inertia for exploration-to-exploitation transition, plus velocity clamping
to prevent divergence.
"""

from __future__ import annotations

import numpy as np
from dataclasses import dataclass
from typing import Callable

from .ga import OptimizationResult


@dataclass
class PSOConfig:
    swarm_size: int = 30
    iterations: int = 40
    inertia_start: float = 0.9
    inertia_end: float = 0.4
    cognitive_coeff: float = 1.6   # c1: pull toward particle's own best
    social_coeff: float = 1.6      # c2: pull toward swarm's global best
    velocity_clamp_frac: float = 0.2  # fraction of parameter range
    seed: int = 0


def run_pso(
    fitness_fn: Callable[[np.ndarray], float],
    bounds_lo: np.ndarray,
    bounds_hi: np.ndarray,
    cfg: PSOConfig = PSOConfig(),
    callback: Callable[[int, np.ndarray, np.ndarray], None] | None = None,
) -> OptimizationResult:
    rng = np.random.default_rng(cfg.seed)
    dim = len(bounds_lo)
    range_ = bounds_hi - bounds_lo
    v_max = cfg.velocity_clamp_frac * range_

    pos = rng.uniform(bounds_lo, bounds_hi, size=(cfg.swarm_size, dim))
    vel = rng.uniform(-v_max, v_max, size=(cfg.swarm_size, dim))

    fitness = np.array([fitness_fn(p) for p in pos])
    pbest_pos = pos.copy()
    pbest_fit = fitness.copy()
    gbest_idx = np.argmin(pbest_fit)
    gbest_pos = pbest_pos[gbest_idx].copy()
    gbest_fit = pbest_fit[gbest_idx]

    history_best, history_mean = [gbest_fit], [fitness.mean()]

    for it in range(cfg.iterations):
        w = cfg.inertia_start + (cfg.inertia_end - cfg.inertia_start) * (it / max(1, cfg.iterations - 1))

        r1 = rng.random((cfg.swarm_size, dim))
        r2 = rng.random((cfg.swarm_size, dim))
        vel = (
            w * vel
            + cfg.cognitive_coeff * r1 * (pbest_pos - pos)
            + cfg.social_coeff * r2 * (gbest_pos - pos)
        )
        vel = np.clip(vel, -v_max, v_max)
        pos = np.clip(pos + vel, bounds_lo, bounds_hi)

        fitness = np.array([fitness_fn(p) for p in pos])

        improved = fitness < pbest_fit
        pbest_pos[improved] = pos[improved]
        pbest_fit[improved] = fitness[improved]

        gen_best_idx = np.argmin(pbest_fit)
        if pbest_fit[gen_best_idx] < gbest_fit:
            gbest_fit = pbest_fit[gen_best_idx]
            gbest_pos = pbest_pos[gen_best_idx].copy()

        history_best.append(gbest_fit)
        history_mean.append(fitness.mean())
        if callback:
            callback(it, gbest_pos, fitness)

    return OptimizationResult(
        best_x=gbest_pos,
        best_fitness=gbest_fit,
        history_best=history_best,
        history_mean=history_mean,
        n_evaluations=cfg.swarm_size * (cfg.iterations + 1),
        method="PSO",
    )
