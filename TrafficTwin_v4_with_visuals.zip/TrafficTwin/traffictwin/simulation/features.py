"""Second-order traffic features that make car-following parameters identifiable.

Mean speed and flow only see the *average* of the dynamics. These four
statistics see its texture:
  speed_std : spatial spread of speeds   -> stop-and-go wave strength (T, a)
  acc_rms   : RMS acceleration           -> responsiveness (a)
  brake_p5  : 5th-percentile accel, |.|  -> hard-braking level (b)
  gap_min   : mean smallest bumper gap   -> jam spacing (s0)
"""
from __future__ import annotations
import numpy as np
from .idm import VEHICLE_LENGTH

FEATURES = ["speed_std", "acc_rms", "brake_p5", "gap_min"]
DT = 0.2


def extract(result, ring_length: float) -> dict:
    v = result.velocity                                   # (T, N)
    acc = np.diff(v, axis=0) / DT
    p = np.sort(result.position % ring_length, axis=1)
    gaps = np.diff(np.concatenate([p, p[:, :1] + ring_length], axis=1), axis=1) - VEHICLE_LENGTH
    return {
        "speed_std": float(v.std(axis=1).mean()),
        "acc_rms": float(np.sqrt((acc ** 2).mean())),
        "brake_p5": float(abs(np.percentile(acc, 5))),
        "gap_min": float(np.maximum(gaps.min(axis=1), 0).mean()),
    }
