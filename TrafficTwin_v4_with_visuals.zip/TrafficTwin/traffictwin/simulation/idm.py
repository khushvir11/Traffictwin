"""
Intelligent Driver Model (IDM) — microscopic car-following simulation
on a single-lane circular ring road.

The ring-road setup is the standard benchmark in traffic-flow calibration
research because it has no boundary conditions (vehicles wrap around),
supports a fixed number of vehicles / density, and reliably reproduces
stop-and-go wave formation — the phenomenon calibration studies try to
reproduce faithfully.

Reference model:
    Treiber, Hennecke & Helbing (2000), "Congested Traffic States in
    Empirical Observations and Microscopic Simulations", Phys. Rev. E 62.
"""

from __future__ import annotations

import numpy as np
from dataclasses import dataclass, field


# Parameter order used everywhere in the project (GA/PSO operate on this vector).
PARAM_NAMES = ["v0", "T", "a", "b", "s0"]

# Reasonable physical bounds for each parameter (SI units: m, s, m/s).
PARAM_BOUNDS = {
    "v0": (15.0, 35.0),   # desired (free-flow) speed, m/s   (~54-126 km/h)
    "T":  (0.5, 3.0),     # desired time headway, s
    "a":  (0.3, 3.0),     # max acceleration, m/s^2
    "b":  (0.5, 5.0),     # comfortable (desired) deceleration, m/s^2
    "s0": (1.0, 5.0),     # minimum (jam) gap, m
}

DELTA = 4.0        # IDM acceleration exponent (standard fixed value)
VEHICLE_LENGTH = 5.0  # m, bumper-to-bumper vehicle length


@dataclass
class SimulationConfig:
    n_vehicles: int = 25
    ring_length: float = 1200.0      # meters
    dt: float = 0.2                  # seconds per integration step
    duration: float = 300.0          # seconds of simulated time
    warmup: float = 60.0             # seconds discarded before data logging
    seed: int = 42


@dataclass
class SimulationResult:
    time: np.ndarray                 # (T,)
    position: np.ndarray             # (T, N) unwrapped positions (m)
    velocity: np.ndarray             # (T, N) speeds (m/s)
    mean_speed: np.ndarray           # (T,) space-mean speed per step (m/s)
    density: float                   # vehicles / km on the ring
    flow_series: np.ndarray = field(default_factory=lambda: np.array([]))  # veh/h estimate per step


def idm_acceleration(v, gap, dv, v0, T, a, b, s0, delta=DELTA):
    """
    Vectorized IDM acceleration.

    v    : own speed (m/s)
    gap  : net (bumper-to-bumper) gap to the leader (m), clipped > 0
    dv   : approaching rate = v - v_leader (m/s); positive = closing in
    """
    gap = np.maximum(gap, 1e-3)
    s_star = s0 + np.maximum(0.0, v * T + (v * dv) / (2.0 * np.sqrt(a * b)))
    accel = a * (1.0 - (v / v0) ** delta - (s_star / gap) ** 2)
    return accel


def _initial_state(cfg: SimulationConfig, rng: np.random.Generator):
    """Evenly space vehicles around the ring with small random speed jitter
    to seed instabilities (needed to observe stop-and-go waves)."""
    spacing = cfg.ring_length / cfg.n_vehicles
    positions = np.arange(cfg.n_vehicles) * spacing
    velocities = np.full(cfg.n_vehicles, 15.0) + rng.normal(0, 0.5, cfg.n_vehicles)
    velocities = np.clip(velocities, 0.0, None)
    return positions, velocities


def run_simulation(params: dict | np.ndarray, cfg: SimulationConfig) -> SimulationResult:
    """
    Run an IDM ring-road simulation for the given driver-behavior parameters.

    params: either a dict with keys PARAM_NAMES, or an array-like in that order.
    """
    if not isinstance(params, dict):
        params = dict(zip(PARAM_NAMES, params))
    v0, T, a, b, s0 = (params[k] for k in PARAM_NAMES)

    rng = np.random.default_rng(cfg.seed)
    n = cfg.n_vehicles
    pos, vel = _initial_state(cfg, rng)

    n_steps = int(cfg.duration / cfg.dt)
    warmup_steps = int(cfg.warmup / cfg.dt)

    time_log, pos_log, vel_log, mean_speed_log, flow_log = [], [], [], [], []

    unwrapped_pos = pos.copy()  # track true distance traveled (no wrap) for plotting

    for step in range(n_steps):
        order = np.argsort(pos % cfg.ring_length)
        sorted_pos = (pos % cfg.ring_length)[order]
        sorted_vel = vel[order]

        leader_pos = np.roll(sorted_pos, -1)
        leader_pos_unwrapped = np.where(leader_pos < sorted_pos, leader_pos + cfg.ring_length, leader_pos)
        gap = leader_pos_unwrapped - sorted_pos - VEHICLE_LENGTH
        leader_vel = np.roll(sorted_vel, -1)
        dv = sorted_vel - leader_vel

        accel_sorted = idm_acceleration(sorted_vel, gap, dv, v0, T, a, b, s0)

        # unsort back to original vehicle indexing
        accel = np.empty(n)
        accel[order] = accel_sorted

        vel = np.maximum(vel + accel * cfg.dt, 0.0)
        pos = pos + vel * cfg.dt
        unwrapped_pos = unwrapped_pos + vel * cfg.dt

        if step >= warmup_steps:
            time_log.append(step * cfg.dt)
            pos_log.append(unwrapped_pos.copy())
            vel_log.append(vel.copy())
            mean_speed_log.append(vel.mean())
            # crude flow estimate via Edie's definitions: flow = density * mean_speed
            density_per_m = n / cfg.ring_length
            flow_log.append(density_per_m * vel.mean() * 3600.0)  # veh/h

    density_per_km = n / (cfg.ring_length / 1000.0)

    return SimulationResult(
        time=np.array(time_log),
        position=np.array(pos_log),
        velocity=np.array(vel_log),
        mean_speed=np.array(mean_speed_log),
        density=density_per_km,
        flow_series=np.array(flow_log),
    )
