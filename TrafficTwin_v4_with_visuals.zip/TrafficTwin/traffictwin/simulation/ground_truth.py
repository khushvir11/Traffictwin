"""
Generates synthetic "observed" traffic data that calibration targets.

In real calibration studies you'd feed in loop-detector or trajectory data
(e.g. NGSIM). Here we manufacture a controlled experiment: simulate the IDM
model with a known "true" parameter set across several vehicle counts
(densities), extract macroscopic measurements (mean speed, flow), and add
sensor noise. The calibration task is then: recover parameters close to the
true set using only the noisy macroscopic measurements — exactly the
information available from real inductive-loop detectors.
"""

from __future__ import annotations

import numpy as np
from dataclasses import dataclass

from .features import extract, FEATURES
from .idm import SimulationConfig, run_simulation, PARAM_NAMES


# The "true" driver-behavior parameters we will try to recover via calibration.
TRUE_PARAMS = {
    "v0": 28.0,   # m/s (~100 km/h desired speed)
    "T": 1.4,     # s
    "a": 1.2,     # m/s^2
    "b": 2.0,     # m/s^2
    "s0": 2.5,    # m
}

# Vehicle counts on the ring used to sweep density -> builds a
# flow-density "fundamental diagram" target, which is far more
# informative for calibration than a single operating point.
VEHICLE_COUNTS = [8, 14, 20, 26, 32, 40, 50, 62]

RING_LENGTH = 1200.0  # meters, fixed ring length across the sweep


@dataclass
class ObservedDataset:
    densities: np.ndarray        # veh/km, one per sweep point
    mean_speeds: np.ndarray      # m/s, noisy observed mean speed per point
    flows: np.ndarray            # veh/h, noisy observed flow per point
    speed_std: np.ndarray        # measurement noise std used (for reference)
    true_params: dict
    extras: dict | None = None   # feature name -> noisy observation per density point


def generate_observed_dataset(
    noise_std_speed: float = 0.6,     # m/s sensor noise on speed
    noise_std_flow_frac: float = 0.05,  # fractional noise on flow
    seed: int = 7,
) -> ObservedDataset:
    """
    Sweep vehicle counts (densities) with the TRUE_PARAMS, run the IDM ring
    simulation for each, and record noisy macroscopic measurements —
    simulating what a set of inductive loop detectors would report.
    """
    rng = np.random.default_rng(seed)
    densities, speeds, flows = [], [], []
    extras = {k: [] for k in FEATURES}

    for i, n_vehicles in enumerate(VEHICLE_COUNTS):
        cfg = SimulationConfig(
            n_vehicles=n_vehicles,
            ring_length=RING_LENGTH,
            dt=0.2,
            duration=240.0,
            warmup=60.0,
            seed=100 + i,  # different traffic realization per density point
        )
        result = run_simulation(TRUE_PARAMS, cfg)

        true_speed = result.mean_speed.mean()
        true_flow = result.flow_series.mean()

        noisy_speed = true_speed + rng.normal(0, noise_std_speed)
        noisy_flow = true_flow * (1.0 + rng.normal(0, noise_std_flow_frac))

        # features use the same 120 s window the optimiser simulates, so they are comparable
        fcfg = SimulationConfig(n_vehicles=n_vehicles, ring_length=RING_LENGTH, dt=0.2, duration=120.0, warmup=40.0, seed=100 + i)
        feats = extract(run_simulation(TRUE_PARAMS, fcfg), RING_LENGTH)
        for k in FEATURES:
            extras[k].append(max(feats[k] * (1.0 + rng.normal(0, noise_std_flow_frac)), 0.0))
        densities.append(result.density)
        speeds.append(max(noisy_speed, 0.1))
        flows.append(max(noisy_flow, 0.0))

    return ObservedDataset(
        densities=np.array(densities),
        mean_speeds=np.array(speeds),
        flows=np.array(flows),
        speed_std=np.full(len(densities), noise_std_speed),
        true_params=dict(TRUE_PARAMS),
        extras={k: np.array(v) for k, v in extras.items()},
    )
