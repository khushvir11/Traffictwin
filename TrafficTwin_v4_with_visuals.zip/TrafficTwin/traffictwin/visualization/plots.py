"""
Plotting utilities: convergence curves, fundamental-diagram fit,
parameter recovery, and trajectory (time-space) diagrams.
"""

from __future__ import annotations

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from ..simulation.idm import PARAM_NAMES, PARAM_BOUNDS, SimulationConfig, run_simulation
from ..simulation.ground_truth import ObservedDataset, VEHICLE_COUNTS, RING_LENGTH


COLORS = {"GA": "#e07a5f", "PSO": "#3d5a80", "Hybrid GA-PSO": "#2a9d8f"}


def plot_convergence(results: dict, save_path: str):
    """results: dict[method_name] -> OptimizationResult"""
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))

    for name, res in results.items():
        color = COLORS.get(name, None)
        axes[0].plot(res.history_best, label=name, color=color, linewidth=2)
        axes[1].plot(res.history_mean, label=name, color=color, linewidth=2)

    axes[0].set_title("Best Fitness Convergence")
    axes[0].set_xlabel("Generation / Iteration")
    axes[0].set_ylabel("Best fitness (RMSE, lower is better)")
    axes[0].legend()
    axes[0].grid(alpha=0.3)

    axes[1].set_title("Mean Population Fitness")
    axes[1].set_xlabel("Generation / Iteration")
    axes[1].set_ylabel("Mean fitness (RMSE)")
    axes[1].legend()
    axes[1].grid(alpha=0.3)

    fig.suptitle("Calibration Optimizer Comparison: GA vs PSO vs Hybrid GA-PSO", fontsize=13)
    fig.tight_layout()
    fig.savefig(save_path, dpi=150)
    plt.close(fig)


def plot_parameter_recovery(results: dict, true_params: dict, bounds: dict, save_path: str):
    """Bar chart comparing recovered parameters vs ground truth for each method."""
    methods = list(results.keys())
    n_params = len(PARAM_NAMES)

    fig, axes = plt.subplots(1, n_params, figsize=(3.2 * n_params, 4))
    x = np.arange(len(methods) + 1)  # +1 for "True"
    labels = ["True"] + methods

    for j, pname in enumerate(PARAM_NAMES):
        values = [true_params[pname]] + [results[m].best_x[j] for m in methods]
        colors = ["#444444"] + [COLORS.get(m, "#999999") for m in methods]
        axes[j].bar(x, values, color=colors)
        axes[j].set_xticks(x)
        axes[j].set_xticklabels(labels, rotation=35, ha="right", fontsize=8)
        axes[j].set_title(pname)
        lo, hi = bounds[pname]
        axes[j].axhspan(lo, hi, color="gray", alpha=0.08)
        axes[j].grid(alpha=0.3, axis="y")

    fig.suptitle("Recovered Parameters vs Ground Truth", fontsize=13)
    fig.tight_layout()
    fig.savefig(save_path, dpi=150)
    plt.close(fig)


def plot_fundamental_diagram(observed: ObservedDataset, calibrated_params: dict, method_name: str, save_path: str):
    """Flow-density and speed-density fundamental diagram: observed (noisy) vs calibrated model."""
    sim_speeds, sim_flows = [], []
    for i, n_vehicles in enumerate(VEHICLE_COUNTS):
        cfg = SimulationConfig(
            n_vehicles=n_vehicles, ring_length=RING_LENGTH,
            dt=0.2, duration=240.0, warmup=60.0, seed=100 + i,
        )
        result = run_simulation(calibrated_params, cfg)
        sim_speeds.append(result.mean_speed.mean())
        sim_flows.append(result.flow_series.mean())

    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))

    axes[0].scatter(observed.densities, observed.mean_speeds, color="#444444", label="Observed (noisy)", zorder=3)
    axes[0].plot(observed.densities, sim_speeds, "o-", color=COLORS.get(method_name, "#2a9d8f"),
                 label=f"{method_name} calibrated", zorder=2)
    axes[0].set_xlabel("Density (veh/km)")
    axes[0].set_ylabel("Mean speed (m/s)")
    axes[0].set_title("Speed-Density Diagram")
    axes[0].legend()
    axes[0].grid(alpha=0.3)

    axes[1].scatter(observed.densities, observed.flows, color="#444444", label="Observed (noisy)", zorder=3)
    axes[1].plot(observed.densities, sim_flows, "o-", color=COLORS.get(method_name, "#2a9d8f"),
                 label=f"{method_name} calibrated", zorder=2)
    axes[1].set_xlabel("Density (veh/km)")
    axes[1].set_ylabel("Flow (veh/h)")
    axes[1].set_title("Flow-Density (Fundamental) Diagram")
    axes[1].legend()
    axes[1].grid(alpha=0.3)

    fig.suptitle(f"Calibration Fit: {method_name}", fontsize=13)
    fig.tight_layout()
    fig.savefig(save_path, dpi=150)
    plt.close(fig)


def plot_trajectories(calibrated_params: dict, n_vehicles: int, save_path: str, title="Time-Space Trajectories (calibrated model)"):
    """Time-space diagram showing stop-and-go wave formation, mod-wrapped onto the ring."""
    cfg = SimulationConfig(n_vehicles=n_vehicles, ring_length=RING_LENGTH, dt=0.2, duration=200.0, warmup=0.0, seed=1)
    result = run_simulation(calibrated_params, cfg)

    fig, ax = plt.subplots(figsize=(9, 5))
    wrapped = result.position % cfg.ring_length
    for i in range(n_vehicles):
        ax.plot(result.time, wrapped[:, i], ",", color="#264653", markersize=1, alpha=0.6)

    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Position on ring (m)")
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(save_path, dpi=150)
    plt.close(fig)
