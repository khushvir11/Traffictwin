"""
TrafficTwin — Hybrid GA-PSO Traffic Simulation Calibration
=============================================================

A digital-twin style toolkit that:
  1. Simulates microscopic car-following traffic (Intelligent Driver Model)
     on a circular test track.
  2. Generates synthetic "ground truth" observed traffic data.
  3. Calibrates the simulation's driver-behavior parameters against that
     data using a Hybrid Genetic Algorithm + Particle Swarm Optimization
     (GA-PSO) metaheuristic, benchmarked against standalone GA and PSO.
"""

__version__ = "1.0.0"
