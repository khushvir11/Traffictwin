"""
Objective (fitness) function used by GA / PSO / Hybrid GA-PSO.

Given a candidate parameter vector, re-run the IDM ring simulation at the
same vehicle counts as the observed dataset, extract mean speed & flow at
each density point, and compute normalized RMSE against the noisy observed
data. Lower is better (0 = perfect fit).
"""

from __future__ import annotations

import numpy as np

from ..simulation.features import extract, FEATURES
from ..simulation.idm import SimulationConfig, run_simulation, PARAM_NAMES
from ..simulation.ground_truth import ObservedDataset, VEHICLE_COUNTS, RING_LENGTH


class CalibrationProblem:
    """
    Wraps an ObservedDataset into a callable fitness function compatible
    with the optimizers in traffictwin.optimization.

    Cheap-simulation mode (fast_eval=True) shortens simulated duration —
    used during optimization search where thousands of evaluations are
    needed. A final high-fidelity re-simulation validates the winning
    parameters.
    """

    def __init__(self, observed: ObservedDataset, fast_eval: bool = True, objective: str = "basic"):
        assert objective in ("basic", "rich")
        self.objective = objective
        self.observed = observed
        self.fast_eval = fast_eval
        self.n_evaluations = 0

        # Normalization constants so speed-RMSE and flow-RMSE contribute
        # comparable magnitudes to the combined objective.
        self._speed_scale = max(observed.mean_speeds.mean(), 1e-6)
        self._flow_scale = max(observed.flows.mean(), 1e-6)

    def _simulate_point(self, params: dict, n_vehicles: int, density_index: int) -> tuple[float, float, dict]:
        duration = 120.0 if self.fast_eval else 240.0
        warmup = 40.0 if self.fast_eval else 60.0
        cfg = SimulationConfig(
            n_vehicles=n_vehicles,
            ring_length=RING_LENGTH,
            dt=0.2,
            duration=duration,
            warmup=warmup,
            seed=100 + density_index,  # match ground_truth's per-point seeding
        )
        result = run_simulation(params, cfg)
        feats = extract(result, RING_LENGTH) if self.objective == "rich" else {}
        return result.mean_speed.mean(), result.flow_series.mean(), feats

    def evaluate(self, x: np.ndarray) -> float:
        """
        x: array-like of length 5 in PARAM_NAMES order [v0, T, a, b, s0].
        Returns scalar fitness (lower = better). Physically invalid
        parameter combinations are heavily penalized rather than crashing.
        """
        self.n_evaluations += 1
        params = dict(zip(PARAM_NAMES, x))

        if params["a"] <= 0 or params["b"] <= 0 or params["v0"] <= 0:
            return 1e6

        sq_err_speed, sq_err_flow = [], []
        sq_feat = {k: [] for k in FEATURES}
        try:
            for i, n_vehicles in enumerate(VEHICLE_COUNTS):
                sim_speed, sim_flow, feats = self._simulate_point(params, n_vehicles, i)
                sq_err_speed.append(((sim_speed - self.observed.mean_speeds[i]) / self._speed_scale) ** 2)
                sq_err_flow.append(((sim_flow - self.observed.flows[i]) / self._flow_scale) ** 2)
                for k, v in feats.items():
                    ref = self.observed.extras[k]
                    sq_feat[k].append(((v - ref[i]) / max(ref.mean(), 1e-6)) ** 2)
        except Exception:
            return 1e6

        rmse_speed = np.sqrt(np.mean(sq_err_speed))
        rmse_flow = np.sqrt(np.mean(sq_err_flow))
        total = rmse_speed + rmse_flow
        if self.objective == "rich":
            # log-compress each feature's RMSE so near-zero equilibrium features can't swamp the landscape
            total += 0.5 * sum(np.log1p(np.sqrt(np.mean(v))) for v in sq_feat.values()) / len(FEATURES)
        return float(total)

    def __call__(self, x: np.ndarray) -> float:
        return self.evaluate(x)
