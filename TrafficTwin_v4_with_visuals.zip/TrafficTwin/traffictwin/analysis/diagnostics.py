"""Post-calibration diagnostics: fitted fundamental diagrams and loss sensitivity.

The sensitivity profile is the honest answer to "why do some parameters
recover badly?" - if the loss barely moves when a parameter is swept across
its whole range, macroscopic speed/flow data simply cannot pin it down.
"""
from __future__ import annotations
import numpy as np
from ..simulation.idm import SimulationConfig, run_simulation, PARAM_NAMES, PARAM_BOUNDS
from ..simulation.ground_truth import RING_LENGTH

CURVE_COUNTS = [6, 10, 14, 18, 22, 26, 30, 36, 42, 50, 58, 66]


def fundamental_curve(params: dict, counts=CURVE_COUNTS) -> dict:
    dens, spd, flw = [], [], []
    for i, n in enumerate(counts):
        cfg = SimulationConfig(n_vehicles=n, ring_length=RING_LENGTH, duration=120.0, warmup=40.0, seed=300 + i)
        r = run_simulation(params, cfg)
        dens.append(r.density); spd.append(float(r.mean_speed.mean())); flw.append(float(r.flow_series.mean()))
    return {"density": [float(d) for d in dens], "speed": spd, "flow": flw}


def sensitivity_profile(problem, center: dict, points: int = 13) -> dict:
    """Sweep each parameter over its bounds with the others held at `center`."""
    out = {}
    for name in PARAM_NAMES:
        lo, hi = PARAM_BOUNDS[name]
        grid = np.linspace(lo, hi, points)
        losses = []
        for g in grid:
            x = dict(center); x[name] = float(g)
            losses.append(float(problem.evaluate([x[k] for k in PARAM_NAMES])))
        losses = np.array(losses)
        out[name] = {"grid": grid.tolist(), "loss": losses.tolist(),
                     "sensitivity": float(losses.max() - losses.min())}
    return out


def param_errors(best: dict, truth: dict) -> dict:
    """Relative error per parameter, normalised by the search-range width."""
    return {k: abs(best[k] - truth[k]) / (PARAM_BOUNDS[k][1] - PARAM_BOUNDS[k][0]) for k in PARAM_NAMES}
